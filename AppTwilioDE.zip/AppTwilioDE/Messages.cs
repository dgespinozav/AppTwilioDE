﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppTwilioDE
{
  
    public class Messages : INotifyPropertyChanged
    {
        /* class that references to data from sql server */


        public DateTime Datetime_created { get; set; }

        public string Phone_to { get; set; }

        public string Message { get; set; }



        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }

}
