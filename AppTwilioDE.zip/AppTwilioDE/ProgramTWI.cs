﻿using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;


namespace AppTwilioDE
{
    class ProgramTWI
    {
 
        public string Sendmessages(string Bodyt,string Phoneto)
        {
            string responsetwi;
            // using enviroment variables to hide credentials //
            string accountSid = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID");
            string authToken = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN");

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                body: Bodyt,
                from: new Twilio.Types.PhoneNumber("+19108768214"),
                to: new Twilio.Types.PhoneNumber("+" + Phoneto)
            );

            Console.WriteLine(message.Sid);

            responsetwi = message.Sid.ToString();

            return responsetwi; 

        }



    }
}
