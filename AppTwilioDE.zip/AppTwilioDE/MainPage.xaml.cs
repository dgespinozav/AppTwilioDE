﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;


namespace AppTwilioDE
{

    public sealed partial class MainPage : Page
    {


        public MainPage()
        {
       

            this.InitializeComponent();
            Loaded += MainPage_Loaded;

            /* get list of allready sent messages */
            MessagesList.ItemsSource = GetMessages((App.Current as App).ConnectionString);

            // Initialize a new list of colors
            List<string> sorts = new List<string>();

            // Put some colors to the list
            sorts.Add("DESC");
            sorts.Add("ASC");
  

            // Finally, Specify the ComboBox items source
            ComboBox1.ItemsSource = sorts;

            ComboBox1.SelectedItem = "ASC";
        }


        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {

            /* SETS APP WINDOW TITLE */
            var appView = Windows.UI.ViewManagement.ApplicationView.GetForCurrentView();
            appView.Title = "SMS DATA APP 2021";

        }


        /*called by click on sort buttom to sort ASc or DESC */
        private void Sort_Click(object sender, RoutedEventArgs e)
        {
            /* get list of allready sent messages */
            MessagesList.ItemsSource = GetMessages((App.Current as App).ConnectionString);
        }

        /* prevent characters on textbox for phone */
        private void TextBox_OnBeforeTextChanging(TextBox sender,TextBoxBeforeTextChangingEventArgs args)
        {
            args.Cancel = args.NewText.Any(c => !char.IsDigit(c));
        }


        /*gets data into stackpanel using connectionstring */
        public ObservableCollection<Messages> GetMessages(string connectionString)
        {
            string ordersequence = "";
            /* How to sort if ASC or DESC */

            if (ComboBox1.SelectedItem != null)
            {
                ordersequence = ComboBox1.SelectedItem.ToString();
             }

            string GetMsgQuery = "select TOP 7 datetime_created, phone_to, message from messages order by datetime_created " + ordersequence + "";

            var msgall = new ObservableCollection<Messages>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    if (conn.State == System.Data.ConnectionState.Open)
                    {
                        using (SqlCommand cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = GetMsgQuery;
                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    var msg1 = new Messages();
                                    msg1.Datetime_created = reader.GetDateTime(0);
                                    msg1.Phone_to = reader.GetString(1);
                                    msg1.Message = reader.GetString(2);
                                    msgall.Add(msg1);
                                }
                            }
                        }
                    }
                }
                return msgall;
            }
            catch (Exception eSql)
            {
                /* any connection exception will be shown here */
                Debug.WriteLine("Exception: " + eSql.Message);
            }
            return null;
        }


        private async void SendSms_Click(object sender, RoutedEventArgs e)
        {
               if (Phone.Text == "" || Phone.Text.Length < 11 )
            {
                /*show error message for bad phone#*/
                ContentDialog badphone = new ContentDialog
                {
                    Title = "Error",
                    Content = "Please fill the Phone 11 digits",
                    CloseButtonText = "Close",
                };

                await badphone.ShowAsync();
                /* clear phone and focus again */
                Phone.Text = String.Empty;
                Phone.Focus(FocusState.Programmatic);

            } else if (String.IsNullOrWhiteSpace(Sms.Text) || Sms.Text.Length < 10  )
            {
                /*show error message for missing msg*/
                ContentDialog badphone = new ContentDialog
                {
                    Title = "Error",
                    Content = "Please enter a message (10 chars at least)",
                    CloseButtonText = "Close",
                };

                await badphone.ShowAsync();
                /* clear message and focus again */
                Sms.Text = String.Empty;
                Sms.Focus(FocusState.Programmatic);
             }
            else
            {
                // Dialog to warn if send or not the message
                ContentDialog sendSmsdialog = new ContentDialog
                {
                    Title = "Sending SMS",
                    Content = "You are about to send a SMS...",
                    CloseButtonText = "Cancel",
                    SecondaryButtonText = "OK"
                };

                ContentDialogResult result = await sendSmsdialog.ShowAsync();

                /* if result is ok then save and send message */
                if (result == ContentDialogResult.Secondary)
                {
                    /* call of method and function */
                    string retconf;
                    ProgramTWI p = new ProgramTWI();
                    retconf = p.Sendmessages(Sms.Text, Phone.Text);
                 

                    try { 
                    using (SqlConnection cnn = new SqlConnection((App.Current as App).ConnectionString))
                    {
                            /* insert into messages table the message on the form */
                        string SaveSent = "INSERT into messages (datetime_created,phone_to,message) VALUES (@datetimec,@phone,@message)";

                        using (SqlCommand QuerySaveSent = new SqlCommand(SaveSent))
                        {
                                QuerySaveSent.Connection = cnn;
                                QuerySaveSent.Parameters.Add("@datetimec", SqlDbType.DateTime).Value = DateTime.Now;
                                QuerySaveSent.Parameters.Add("@phone", SqlDbType.VarChar,50).Value = Phone.Text;
                                QuerySaveSent.Parameters.Add("@message", SqlDbType.VarChar, 100).Value = Sms.Text;

                            cnn.Open();

                                QuerySaveSent.ExecuteNonQuery();
                        }

                            cnn.Close();

                            /* insert into messages sent the response*/
                            SaveSent = "INSERT into messages_sent (messages_id,datetime_sent,confirmation_code) VALUES ((Select MAX(messages_id) from messages),@datetimes,@confirmation)";

                            using (SqlCommand QuerySaveConf = new SqlCommand(SaveSent))
                            {
                                QuerySaveConf.Connection = cnn;
                                QuerySaveConf.Parameters.Add("@datetimes", SqlDbType.DateTime).Value = DateTime.Now;
                                QuerySaveConf.Parameters.Add("@confirmation", SqlDbType.VarChar, 100).Value = retconf;

                                cnn.Open();

                                QuerySaveConf.ExecuteNonQuery();
                            }


                            cnn.Close();

                            /* get list of allready sent messages */
                            MessagesList.ItemsSource = GetMessages((App.Current as App).ConnectionString);

                            /* Clear fields since save was successfull and focus on phone again */
                            Phone.Text = String.Empty;
                            Sms.Text = String.Empty;
                            Phone.Focus(FocusState.Programmatic);


                            /*confirmation message*/
                            ContentDialog successsave = new ContentDialog
                            {
                                Title = "MESSAGE SENT SUCCESSFULLY!",
                                Content = "MESSAGE SENT, CONFIRMATION : " + retconf,
                                CloseButtonText = "OK",
                            };

                            await successsave.ShowAsync();



                        }

                    }
                    catch (Exception eSql)
                    {
                        /* any connection exception will be shown here */
                        Debug.WriteLine("Exception: " + eSql.Message);
                    }
         
                }



            }
            
        }








        }



}
